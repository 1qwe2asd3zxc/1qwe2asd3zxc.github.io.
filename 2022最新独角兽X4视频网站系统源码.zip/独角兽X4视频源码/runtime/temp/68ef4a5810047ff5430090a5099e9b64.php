<?php if (!defined('THINK_PATH')) exit(); /*a:5:{s:38:"template/8x8x_ym/html/index/index.html";i:1597132800;s:101:"/usr/local/lighthouse/softwares/btpanel/wwwroot/13.hoozy.cn/template/8x8x_ym/html/public/include.html";i:1597132800;s:98:"/usr/local/lighthouse/softwares/btpanel/wwwroot/13.hoozy.cn/template/8x8x_ym/html/public/head.html";i:1597132800;s:98:"/usr/local/lighthouse/softwares/btpanel/wwwroot/13.hoozy.cn/template/8x8x_ym/html/public/foot.html";i:1597132800;s:99:"/usr/local/lighthouse/softwares/btpanel/wwwroot/13.hoozy.cn/template/8x8x_ym/html/public/popup.html";i:1597132800;}*/ ?>
<!DOCTYPE html>
<html>
 <head> 
  <meta http-equiv="Content-Type" content="text/html; charset=utf-8" /> 
  <meta http-equiv="x-ua-compatible" content="ie=edge,chrome=1" /> 
  <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no, viewport-fit=cover" /> 
  <meta name="format-detection" content="telephone=no" /> 
  <title><?php echo $maccms['site_name']; ?></title>  
  <meta name="description" content="<?php echo $maccms['site_description']; ?>" /> 
  <meta name="keywords" content="<?php echo $maccms['site_keywords']; ?>" />
  <link rel="shortcut icon" href="/favicon.ico" />
<link rel="stylesheet" href="<?php echo $maccms['path']; ?>static/css/style.css" type="text/css" /> 
<script src="<?php echo $maccms['path']; ?>static/js/jquery.min.js" type="text/javascript"></script> 
<script src="<?php echo $maccms['path']; ?>static/js/jquery.lazyload.min.js"></script> 
<script src="<?php echo $maccms['path']; ?>static/js/clipboard.min.js" type="text/javascript"></script> 
<script type="text/javascript" src="<?php echo $maccms['path']; ?>static/js/jquery.SuperSlide.2.1.1.js"></script>
<script src="<?php echo $maccms['path']; ?>static/js/jquery.autocomplete.js"></script>
<script src="<?php echo $maccms['path']; ?>static/js/jquery.base.js"></script>
<script>var maccms={"path":"","mid":"<?php echo $maccms['mid']; ?>","aid":"<?php echo $maccms['aid']; ?>","url":"<?php echo $maccms['site_url']; ?>","wapurl":"<?php echo $maccms['site_wapurl']; ?>","mob_status":"<?php echo $maccms['mob_status']; ?>"};</script>
<script src="<?php echo $maccms['path']; ?>static/js/home.js"></script>
 </head>
 <body>
    <div class="top"> 
   <div class="container"> 
    <div class="sc_bz">
     <?php if($GLOBALS['user']['user_id']): ?>
     <a class="upload_url" href="<?php echo mac_url('user/index'); ?>" target="_blank" rel="noopener noreferrer">会员中心</a>
     <?php else: ?>
     <a class="upload_url" href="<?php echo mac_url('user/login'); ?>" target="_blank" rel="noopener noreferrer">会员中心</a>
     <?php endif; ?>
    </div> 
    <div class="dz_zx">
     <a class="url_page" href="<?php echo mac_url('user/findpass_msg'); ?>?ac=email" target="_blank" rel="noopener noreferrer">找回密码</a>
    </div> 
    <?php $__TAG__ = '{"order":"desc","ids":"2","id":"vo","key":"key"}';$__LIST__ = model("Website")->listCacheData($__TAG__); if(is_array($__LIST__['list']) || $__LIST__['list'] instanceof \think\Collection || $__LIST__['list'] instanceof \think\Paginator): $key = 0; $__LIST__ = $__LIST__['list'];if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($key % 2 );++$key;?>
    <div class="rj_xz">
     <a class="app_link" href="<?php echo $vo['website_jumpurl']; ?>" target="_blank" rel="noopener noreferrer">APP下载</a>
    </div> 
    <?php endforeach; endif; else: echo "" ;endif; ?>
    <div class="logo">
     <a class="header_logo" href="/"><img src="<?php echo mac_url_img($maccms['site_logo']); ?>" /></a>
    </div> 
    <div class="clear"></div> 
   </div> 
  </div> 
  <!-- top --> 
  <?php $__TAG__ = '{"order":"desc","ids":"3","id":"vo","key":"key"}';$__LIST__ = model("Website")->listCacheData($__TAG__); if(is_array($__LIST__['list']) || $__LIST__['list'] instanceof \think\Collection || $__LIST__['list'] instanceof \think\Paginator): $key = 0; $__LIST__ = $__LIST__['list'];if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($key % 2 );++$key;?>
  <div class="top_gg container">
   <a href="<?php echo $vo['website_jumpurl']; ?>" target="_blank"><img class="lazy" src="<?php echo mac_url_img($vo['website_logo']); ?>" style="display: block;"></a>
  </div>
  <?php endforeach; endif; else: echo "" ;endif; ?>
  <!-- top_ads --> 
  <div class="header"> 
   <div class="container"> 
    <div class="logo">
     <a href="/"><img src="<?php echo mac_url_img($maccms['site_logo']); ?>" /></a>
    </div> 
    <div class="menu"> 
     <ul> 
      <li class="a_n"><a href="javascript:;"><img src="<?php echo $maccms['path']; ?>static/img/an.png" /></a></li> 
      <li class="on"><a href="/">首页</a></li> 
	  <?php $__TAG__ = '{"order":"asc","by":"sort","ids":"parent","id":"vo","key":"key"}';$__LIST__ = model("Type")->listCacheData($__TAG__); if(is_array($__LIST__['list']) || $__LIST__['list'] instanceof \think\Collection || $__LIST__['list'] instanceof \think\Paginator): $key = 0; $__LIST__ = $__LIST__['list'];if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($key % 2 );++$key;?>
      <li><a href="<?php echo mac_url_type($vo); ?>" target="_blank" rel="noopener noreferrer"><?php echo $vo['type_name']; ?></a></li> 
	  <?php endforeach; endif; else: echo "" ;endif; ?>
      <li><a href="<?php echo mac_url('vod/search'); ?>" target="_blank" rel="noopener noreferrer">搜索</a></li> 
     </ul> 
    </div> 
    <div class="clear"></div> 
   </div> 
   <div class="lm_fl"> 
    <div class="l_m">
     栏目：
    </div> 
    <?php $__TAG__ = '{"order":"asc","by":"sort","ids":"parent","id":"vo1","key":"key1"}';$__LIST__ = model("Type")->listCacheData($__TAG__); if(is_array($__LIST__['list']) || $__LIST__['list'] instanceof \think\Collection || $__LIST__['list'] instanceof \think\Paginator): $key1 = 0; $__LIST__ = $__LIST__['list'];if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo1): $mod = ($key1 % 2 );++$key1;?>
    <div class="f_l"> 
     <ul> 
      <li><a href="<?php echo mac_url_type($vo1); ?>" class="on" target="_blank" rel="noopener noreferrer"><?php echo $vo1['type_name']; ?></a></li> 
	  <?php $__TAG__ = '{"order":"asc","by":"sort","ids":"child","id":"vo","key":"key"}';$__LIST__ = model("Type")->listCacheData($__TAG__); if(is_array($__LIST__['list']) || $__LIST__['list'] instanceof \think\Collection || $__LIST__['list'] instanceof \think\Paginator): $key = 0; $__LIST__ = $__LIST__['list'];if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($key % 2 );++$key;if($vo['type_pid'] == $vo1['type_id']): ?>
      <li><a href="<?php echo mac_url_type($vo); ?>" target="_blank" rel="noopener noreferrer"><?php echo $vo['type_name']; ?></a></li>
	  <?php endif; endforeach; endif; else: echo "" ;endif; ?>
     </ul> 
    </div> 
	<?php endforeach; endif; else: echo "" ;endif; ?>
    <div class="clear"></div>
   </div> 
   <?php $__TAG__ = '{"order":"desc","ids":"4","id":"vo","key":"key"}';$__LIST__ = model("Website")->listCacheData($__TAG__); if(is_array($__LIST__['list']) || $__LIST__['list'] instanceof \think\Collection || $__LIST__['list'] instanceof \think\Paginator): $key = 0; $__LIST__ = $__LIST__['list'];if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($key % 2 );++$key;?>
   <div class="zc_gg">
    <a href="<?php echo $vo['website_jumpurl']; ?>" target="_blank"><img class="lazy" src="<?php echo mac_url_img($vo['website_logo']); ?>" style="display: block;"></a>
   </div>
   <?php endforeach; endif; else: echo "" ;endif; $__TAG__ = '{"order":"desc","ids":"5","id":"vo","key":"key"}';$__LIST__ = model("Website")->listCacheData($__TAG__); if(is_array($__LIST__['list']) || $__LIST__['list'] instanceof \think\Collection || $__LIST__['list'] instanceof \think\Paginator): $key = 0; $__LIST__ = $__LIST__['list'];if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($key % 2 );++$key;?>
   <div class="yc_gg">
    <a href="<?php echo $vo['website_jumpurl']; ?>" target="_blank"><img class="lazy" src="<?php echo mac_url_img($vo['website_logo']); ?>" style="display: block;"></a>
   </div>
   <?php endforeach; endif; else: echo "" ;endif; ?>
  </div> 
  <?php $__TAG__ = '{"order":"desc","ids":"6","id":"vo","key":"key"}';$__LIST__ = model("Website")->listCacheData($__TAG__); if(is_array($__LIST__['list']) || $__LIST__['list'] instanceof \think\Collection || $__LIST__['list'] instanceof \think\Paginator): $key = 0; $__LIST__ = $__LIST__['list'];if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($key % 2 );++$key;?>
  <div class="head_gg head_1 container">
   <a href="<?php echo $vo['website_jumpurl']; ?>" target="_blank"><img class="lazy" src="<?php echo mac_url_img($vo['website_logo']); ?>" style="display: block;"></a>
  </div> 
  <?php endforeach; endif; else: echo "" ;endif; $__TAG__ = '{"order":"desc","ids":"7","id":"vo","key":"key"}';$__LIST__ = model("Website")->listCacheData($__TAG__); if(is_array($__LIST__['list']) || $__LIST__['list'] instanceof \think\Collection || $__LIST__['list'] instanceof \think\Paginator): $key = 0; $__LIST__ = $__LIST__['list'];if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($key % 2 );++$key;?>
  <div class="head_gg head_2 container">
   <a href="<?php echo $vo['website_jumpurl']; ?>" target="_blank"><img class="lazy" src="<?php echo mac_url_img($vo['website_logo']); ?>" style="display: block;"></a>
  </div> 
  <?php endforeach; endif; else: echo "" ;endif; $__TAG__ = '{"order":"desc","ids":"19","id":"vo","key":"key"}';$__LIST__ = model("Website")->listCacheData($__TAG__); if(is_array($__LIST__['list']) || $__LIST__['list'] instanceof \think\Collection || $__LIST__['list'] instanceof \think\Paginator): $key = 0; $__LIST__ = $__LIST__['list'];if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($key % 2 );++$key;?>
  <div class="sj_gg">
   <a href="<?php echo $vo['website_jumpurl']; ?>" target="_blank"><img class="lazy" src="<?php echo mac_url_img($vo['website_logo']); ?>" style="display: block;"></a>
  </div> 
  <?php endforeach; endif; else: echo "" ;endif; $__TAG__ = '{"order":"desc","ids":"1","id":"vo","key":"key"}';$__LIST__ = model("Website")->listCacheData($__TAG__); if(is_array($__LIST__['list']) || $__LIST__['list'] instanceof \think\Collection || $__LIST__['list'] instanceof \think\Paginator): $key = 0; $__LIST__ = $__LIST__['list'];if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($key % 2 );++$key;?>
  <div class="container tipsforu" id="gotovideo"><?php echo mac_filter_html($vo['website_content']); ?></div> 
  <?php endforeach; endif; else: echo "" ;endif; ?>
  <!-- head_ads --> 
  <div class="sy_yp container"> 
   <div class="gy_bt"> 
    <div class="l_m" style="background: url('<?php echo $maccms['path']; ?>static/images/img/bg_icon.png') no-repeat -20px -773px;">
     视频
    </div> 
    <div class="hd"> 
     <ul> 
      <li>最热</li> 
	  <?php $__TAG__ = '{"order":"asc","by":"sort","ids":"child","id":"vo","key":"key"}';$__LIST__ = model("Type")->listCacheData($__TAG__); if(is_array($__LIST__['list']) || $__LIST__['list'] instanceof \think\Collection || $__LIST__['list'] instanceof \think\Paginator): $key = 0; $__LIST__ = $__LIST__['list'];if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($key % 2 );++$key;if($vo['type_pid'] == 1): ?>
      <li><?php echo $vo['type_name']; ?></li>
	  <?php endif; endforeach; endif; else: echo "" ;endif; ?>
     </ul> 
    </div> 
    <div class="more_btn"> 
	 <?php $__TAG__ = '{"order":"asc","by":"sort","ids":"1","id":"vo","key":"key"}';$__LIST__ = model("Type")->listCacheData($__TAG__); if(is_array($__LIST__['list']) || $__LIST__['list'] instanceof \think\Collection || $__LIST__['list'] instanceof \think\Paginator): $key = 0; $__LIST__ = $__LIST__['list'];if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($key % 2 );++$key;?>
     <a href="<?php echo mac_url_type($vo); ?>" class="gd_lm">更多视频</a> 
	 <?php endforeach; endif; else: echo "" ;endif; $__TAG__ = '{"order":"asc","by":"sort","ids":"child","id":"vo","key":"key"}';$__LIST__ = model("Type")->listCacheData($__TAG__); if(is_array($__LIST__['list']) || $__LIST__['list'] instanceof \think\Collection || $__LIST__['list'] instanceof \think\Paginator): $key = 0; $__LIST__ = $__LIST__['list'];if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($key % 2 );++$key;if($vo['type_pid'] == 1): ?>
     <a href="<?php echo mac_url_type($vo); ?>" class="gd_lm">更多<?php echo $vo['type_name']; ?></a>
	 <?php endif; endforeach; endif; else: echo "" ;endif; ?>
    </div> 
    <div class="clear"></div> 
   </div> 
   <div class="yp_nr"> 
    <ul> 
	<?php $__TAG__ = '{"order":"desc","by":"hits","num":"12","type":"1","id":"vo","key":"key"}';$__LIST__ = model("Vod")->listCacheData($__TAG__); if(is_array($__LIST__['list']) || $__LIST__['list'] instanceof \think\Collection || $__LIST__['list'] instanceof \think\Paginator): $key = 0; $__LIST__ = $__LIST__['list'];if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($key % 2 );++$key;?>
     <li> 
      <div class="t_p">
       <a href="<?php echo mac_url_vod_play($vo); ?>" target="_blank" rel="noopener noreferrer"><img class="lazy" data-original="<?php echo mac_url_img($vo['vod_pic']); ?>" src="<?php echo $maccms['path']; ?>static/img/lazylitpic.gif" /></a>
       <?php if(!(empty($vo['vod_duration']) || (($vo['vod_duration'] instanceof \think\Collection || $vo['vod_duration'] instanceof \think\Paginator ) && $vo['vod_duration']->isEmpty()))): ?><span><?php echo $vo['vod_duration']; ?></span><?php endif; ?>
      </div> 
      <div class="w_z"> 
       <h3><a href="<?php echo mac_url_vod_play($vo); ?>" target="_blank" rel="noopener noreferrer"><?php echo $vo['vod_name']; ?></a></h3> 
       <span><?php echo date("Y年m月d日",$vo['vod_time']); ?></span> 
      </div> 
      <div class="clear"></div> </li>  
	<?php endforeach; endif; else: echo "" ;endif; $__TAG__ = '{"order":"desc","ids":"21","id":"vo","key":"key"}';$__LIST__ = model("Website")->listCacheData($__TAG__); if(is_array($__LIST__['list']) || $__LIST__['list'] instanceof \think\Collection || $__LIST__['list'] instanceof \think\Paginator): $key = 0; $__LIST__ = $__LIST__['list'];if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($key % 2 );++$key;?>
     <li class="navadz_index">
      <div class="t_p"><a href="<?php echo $vo['website_jumpurl']; ?>" target="_blank"><img class="lazy" src="<?php echo mac_url_img($vo['website_logo']); ?>" style="display: block;"></a></div><div class="w_z"><h3><a href="<?php echo $vo['website_jumpurl']; ?>" target="_blank"><?php echo $vo['website_sub']; ?></a></h3><span><?php echo date("Y年m月d日",$vo['website_time']); ?></span></div><div class="clear"></div>
     </li>
     <?php endforeach; endif; else: echo "" ;endif; $__TAG__ = '{"order":"desc","ids":"22","id":"vo","key":"key"}';$__LIST__ = model("Website")->listCacheData($__TAG__); if(is_array($__LIST__['list']) || $__LIST__['list'] instanceof \think\Collection || $__LIST__['list'] instanceof \think\Paginator): $key = 0; $__LIST__ = $__LIST__['list'];if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($key % 2 );++$key;?>
     <li class="navady_index">
      <div class="t_p"><a href="<?php echo $vo['website_jumpurl']; ?>" target="_blank"><img class="lazy" src="<?php echo mac_url_img($vo['website_logo']); ?>" style="display: block;"></a></div><div class="w_z"><h3><a href="<?php echo $vo['website_jumpurl']; ?>" target="_blank"><?php echo $vo['website_sub']; ?></a></h3><span><?php echo date("Y年m月d日",$vo['website_time']); ?></span></div><div class="clear"></div>
     </li> 
     <?php endforeach; endif; else: echo "" ;endif; ?>
    </ul> 
	<?php $__TAG__ = '{"order":"asc","by":"sort","ids":"child","id":"vo","key":"key"}';$__LIST__ = model("Type")->listCacheData($__TAG__); if(is_array($__LIST__['list']) || $__LIST__['list'] instanceof \think\Collection || $__LIST__['list'] instanceof \think\Paginator): $key = 0; $__LIST__ = $__LIST__['list'];if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($key % 2 );++$key;if($vo['type_pid'] == 1): ?>
    <ul> 
	 <?php $__TAG__ = '{"order":"desc","by":"hits","num":"12","type":"'.$vo['type_id'].'","id":"vo1","key":"key1"}';$__LIST__ = model("Vod")->listCacheData($__TAG__); if(is_array($__LIST__['list']) || $__LIST__['list'] instanceof \think\Collection || $__LIST__['list'] instanceof \think\Paginator): $key1 = 0; $__LIST__ = $__LIST__['list'];if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo1): $mod = ($key1 % 2 );++$key1;?>
     <li> 
      <div class="t_p">
       <a href="<?php echo mac_url_vod_play($vo1); ?>" target="_blank" rel="noopener noreferrer"><img data-original="<?php echo mac_url_img($vo1['vod_pic']); ?>" src="<?php echo $maccms['path']; ?>static/img/lazylitpic.gif" /></a>
       <?php if(!(empty($vo['vod_duration']) || (($vo['vod_duration'] instanceof \think\Collection || $vo['vod_duration'] instanceof \think\Paginator ) && $vo['vod_duration']->isEmpty()))): ?><span><?php echo $vo['vod_duration']; ?></span><?php endif; ?>
      </div> 
      <div class="w_z"> 
       <h3><a href="<?php echo mac_url_vod_play($vo1); ?>" target="_blank" rel="noopener noreferrer"><?php echo $vo1['vod_name']; ?></a></h3> 
       <span><?php echo date("Y年m月d日",$vo1['vod_time']); ?></span> 
      </div> 
      <div class="clear"></div> </li> 
	 <?php endforeach; endif; else: echo "" ;endif; ?>
     <li class="navadz_index"></li>
     <li class="navady_index"></li> 
    </ul> 
	<?php endif; endforeach; endif; else: echo "" ;endif; ?>
   </div> 
   <div class="clear"></div> 
   <div class="gy_bt"> 
    <div class="l_m" style="background: url('<?php echo $maccms['path']; ?>static/images/img/bg_icon.png') no-repeat -20px -773px;">
     分类
    </div> 
    <div class="hd"> 
     <ul> 
	  <?php $__TAG__ = '{"order":"asc","by":"sort","ids":"child","id":"vo","key":"key"}';$__LIST__ = model("Type")->listCacheData($__TAG__); if(is_array($__LIST__['list']) || $__LIST__['list'] instanceof \think\Collection || $__LIST__['list'] instanceof \think\Paginator): $key = 0; $__LIST__ = $__LIST__['list'];if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($key % 2 );++$key;if($vo['type_pid'] == 1): ?>
      <li><a href="<?php echo mac_url_type($vo); ?>"><?php echo $vo['type_name']; ?></a></li>
	  <?php endif; endforeach; endif; else: echo "" ;endif; ?>
     </ul> 
    </div> 
    <div class="clear"></div> 
   </div> 
  </div> 
  <script type="text/javascript">
  jQuery(".sy_yp").slide({mainCell:".yp_nr",targetCell:".more_btn a",trigger:"click",switchLoad:"data-original",delayTime:100,});
</script> 
  <?php $__TAG__ = '{"order":"desc","ids":"8","id":"vo","key":"key"}';$__LIST__ = model("Website")->listCacheData($__TAG__); if(is_array($__LIST__['list']) || $__LIST__['list'] instanceof \think\Collection || $__LIST__['list'] instanceof \think\Paginator): $key = 0; $__LIST__ = $__LIST__['list'];if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($key % 2 );++$key;?>
  <div class="head_gg sy_sp container" id="gotoimage">
   <a href="<?php echo $vo['website_jumpurl']; ?>" target="_blank"><img class="lazy" src="<?php echo mac_url_img($vo['website_logo']); ?>" style="display: block;"></a>
  </div> 
  <?php endforeach; endif; else: echo "" ;endif; ?>
  <div class="sy_tc container"> 
   <div class="gy_bt"> 
    <div class="l_m" style="background: url('<?php echo $maccms['path']; ?>static/images/img/bg_icon.png') no-repeat -20px -613px;">
     图片
    </div> 
	<?php $__TAG__ = '{"order":"asc","by":"sort","ids":"2","id":"vo","key":"key"}';$__LIST__ = model("Type")->listCacheData($__TAG__); if(is_array($__LIST__['list']) || $__LIST__['list'] instanceof \think\Collection || $__LIST__['list'] instanceof \think\Paginator): $key = 0; $__LIST__ = $__LIST__['list'];if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($key % 2 );++$key;?>
    <a href="<?php echo mac_url_type($vo); ?>" class="gd_lm">更多图片</a> 
    <a href="<?php echo mac_url_type($vo); ?>" class="fy_lm"><img src="<?php echo $maccms['path']; ?>static/img/fy.png" /></a> 
	<?php endforeach; endif; else: echo "" ;endif; ?>
    <div class="clear"></div> 
   </div> 
   <div class="tc_nr"> 
    <ul> 
	<?php $__TAG__ = '{"order":"desc","by":"time","type":"2","num":"8","id":"vo","key":"key"}';$__LIST__ = model("Art")->listCacheData($__TAG__); if(is_array($__LIST__['list']) || $__LIST__['list'] instanceof \think\Collection || $__LIST__['list'] instanceof \think\Paginator): $key = 0; $__LIST__ = $__LIST__['list'];if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($key % 2 );++$key;?>
     <li> 
      <div class="t_p">
       <a href="<?php echo mac_url_art_detail($vo); ?>" target="_blank" rel="noopener noreferrer"><img class="lazy" data-original="<?php echo mac_url_img($vo['art_pic']); ?>" src="<?php echo $maccms['path']; ?>static/img/lazylitpic.gif" /></a>
       <?php if(!(empty($vo['art_remarks']) || (($vo['art_remarks'] instanceof \think\Collection || $vo['art_remarks'] instanceof \think\Paginator ) && $vo['art_remarks']->isEmpty()))): ?><span><?php echo $vo['art_remarks']; ?></span><?php endif; ?>
      </div> 
      <div class="w_z"> 
       <h3><a href="<?php echo mac_url_art_detail($vo); ?>" target="_blank" rel="noopener noreferrer"><?php echo $vo['art_name']; ?></a></h3> 
       <span><?php echo date("Y-m-d",$vo['art_time']); ?></span> 
      </div> 
      <div class="clear"></div> </li> 
	<?php endforeach; endif; else: echo "" ;endif; ?>
    </ul> 
    <div class="clear"></div> 
   </div> 
  </div> 
  <?php $__TAG__ = '{"order":"desc","ids":"9","id":"vo","key":"key"}';$__LIST__ = model("Website")->listCacheData($__TAG__); if(is_array($__LIST__['list']) || $__LIST__['list'] instanceof \think\Collection || $__LIST__['list'] instanceof \think\Paginator): $key = 0; $__LIST__ = $__LIST__['list'];if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($key % 2 );++$key;?>
  <div class="head_gg sy_tp container" id="gotofiction">
   <a href="<?php echo $vo['website_jumpurl']; ?>" target="_blank"><img class="lazy" src="<?php echo mac_url_img($vo['website_logo']); ?>" style="display: block;"></a>
  </div>  
  <?php endforeach; endif; else: echo "" ;endif; ?>
  <div class="sy_xw container"> 
   <div class="gy_bt"> 
    <div class="l_m" style="background: url('<?php echo $maccms['path']; ?>static/images/img/bg_icon.png') no-repeat -20px -453px;">
     小说
    </div> 
	<?php $__TAG__ = '{"order":"asc","by":"sort","ids":"3","id":"vo","key":"key"}';$__LIST__ = model("Type")->listCacheData($__TAG__); if(is_array($__LIST__['list']) || $__LIST__['list'] instanceof \think\Collection || $__LIST__['list'] instanceof \think\Paginator): $key = 0; $__LIST__ = $__LIST__['list'];if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($key % 2 );++$key;?>
    <a href="<?php echo mac_url_type($vo); ?>" class="gd_lm">更多小说</a> 
    <a href="<?php echo mac_url_type($vo); ?>" class="fy_lm"><img src="<?php echo $maccms['path']; ?>static/img/fy.png" /></a> 
	<?php endforeach; endif; else: echo "" ;endif; ?>
    <div class="clear"></div> 
   </div> 
   <div class="xw_nr"> 
    <ul>
	<?php $__TAG__ = '{"order":"desc","by":"time","type":"3","num":"10","id":"vo","key":"key"}';$__LIST__ = model("Art")->listCacheData($__TAG__); if(is_array($__LIST__['list']) || $__LIST__['list'] instanceof \think\Collection || $__LIST__['list'] instanceof \think\Paginator): $key = 0; $__LIST__ = $__LIST__['list'];if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($key % 2 );++$key;?>	
     <li><span><?php echo date("Y-m-d",$vo['art_time']); ?></span><a href="<?php echo mac_url_art_detail($vo); ?>" target="_blank" rel="noopener noreferrer"><?php echo $vo['art_name']; ?></a></li> 
	<?php endforeach; endif; else: echo "" ;endif; ?>
    </ul> 
   </div> 
  </div> 
  <?php $__TAG__ = '{"order":"desc","ids":"10","id":"vo","key":"key"}';$__LIST__ = model("Website")->listCacheData($__TAG__); if(is_array($__LIST__['list']) || $__LIST__['list'] instanceof \think\Collection || $__LIST__['list'] instanceof \think\Paginator): $key = 0; $__LIST__ = $__LIST__['list'];if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($key % 2 );++$key;?>
  <div class="head_gg sy_xs container">
   <a href="<?php echo $vo['website_jumpurl']; ?>" target="_blank"><img class="lazy" src="<?php echo mac_url_img($vo['website_logo']); ?>" style="display: block;"></a>
  </div> 
  <?php endforeach; endif; else: echo "" ;endif; ?>
    <div class="footer"> 
   <div class="container">  
    <div class="ft_gg"> 
     <ul> 
      <?php $__TAG__ = '{"order":"desc","ids":"11","id":"vo","key":"key"}';$__LIST__ = model("Website")->listCacheData($__TAG__); if(is_array($__LIST__['list']) || $__LIST__['list'] instanceof \think\Collection || $__LIST__['list'] instanceof \think\Paginator): $key = 0; $__LIST__ = $__LIST__['list'];if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($key % 2 );++$key;?>
      <li class="foot_b1">
	   <a href="<?php echo $vo['website_jumpurl']; ?>" target="_blank"><img class="lazy" src="<?php echo mac_url_img($vo['website_logo']); ?>" style="display: block;"></a>
	  </li> 
	  <?php endforeach; endif; else: echo "" ;endif; $__TAG__ = '{"order":"desc","ids":"12","id":"vo","key":"key"}';$__LIST__ = model("Website")->listCacheData($__TAG__); if(is_array($__LIST__['list']) || $__LIST__['list'] instanceof \think\Collection || $__LIST__['list'] instanceof \think\Paginator): $key = 0; $__LIST__ = $__LIST__['list'];if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($key % 2 );++$key;?>
      <li class="foot_b2">
	   <a href="<?php echo $vo['website_jumpurl']; ?>" target="_blank"><img class="lazy" src="<?php echo mac_url_img($vo['website_logo']); ?>" style="display: block;"></a>
	  </li> 
	  <?php endforeach; endif; else: echo "" ;endif; $__TAG__ = '{"order":"desc","ids":"13","id":"vo","key":"key"}';$__LIST__ = model("Website")->listCacheData($__TAG__); if(is_array($__LIST__['list']) || $__LIST__['list'] instanceof \think\Collection || $__LIST__['list'] instanceof \think\Paginator): $key = 0; $__LIST__ = $__LIST__['list'];if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($key % 2 );++$key;?>
      <li class="foot_b3">
	   <a href="<?php echo $vo['website_jumpurl']; ?>" target="_blank"><img class="lazy" src="<?php echo mac_url_img($vo['website_logo']); ?>" style="display: block;"></a>
	  </li> 
	  <?php endforeach; endif; else: echo "" ;endif; $__TAG__ = '{"order":"desc","ids":"14","id":"vo","key":"key"}';$__LIST__ = model("Website")->listCacheData($__TAG__); if(is_array($__LIST__['list']) || $__LIST__['list'] instanceof \think\Collection || $__LIST__['list'] instanceof \think\Paginator): $key = 0; $__LIST__ = $__LIST__['list'];if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($key % 2 );++$key;?>
      <li class="foot_b4">
	   <a href="<?php echo $vo['website_jumpurl']; ?>" target="_blank"><img class="lazy" src="<?php echo mac_url_img($vo['website_logo']); ?>" style="display: block;"></a>
	  </li> 
	  <?php endforeach; endif; else: echo "" ;endif; ?>
     </ul> 
     <div class="clear"></div> 
    </div> 
    <div class="ft_xx"> 
     <div class="zc_nr"> 
      <ul> 
	  <?php $__TAG__ = '{"order":"asc","by":"sort","ids":"parent","id":"vo1","key":"key1"}';$__LIST__ = model("Type")->listCacheData($__TAG__); if(is_array($__LIST__['list']) || $__LIST__['list'] instanceof \think\Collection || $__LIST__['list'] instanceof \think\Paginator): $key1 = 0; $__LIST__ = $__LIST__['list'];if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo1): $mod = ($key1 % 2 );++$key1;?>
       <li class="ft_nav"><a href="<?php echo mac_url_type($vo1); ?>" target="_blank" rel="noopener noreferrer"><?php echo $vo1['type_name']; ?></a></li> 
	   <?php $__TAG__ = '{"order":"asc","by":"sort","ids":"child","id":"vo","key":"key"}';$__LIST__ = model("Type")->listCacheData($__TAG__); if(is_array($__LIST__['list']) || $__LIST__['list'] instanceof \think\Collection || $__LIST__['list'] instanceof \think\Paginator): $key = 0; $__LIST__ = $__LIST__['list'];if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($key % 2 );++$key;if($vo['type_pid'] == $vo1['type_id']): ?>
       <li><a href="<?php echo mac_url_type($vo); ?>" target="_blank" rel="noopener noreferrer"><?php echo $vo['type_name']; ?></a></li>
	   <?php endif; endforeach; endif; else: echo "" ;endif; endforeach; endif; else: echo "" ;endif; ?>
       <li class="ft_nav"><a href="/">首页</a></li> 
      </ul> 
      <div class="clear"></div> 
     </div> 
     <div class="yc_nr"> 
      <div class="l_m"> 
       <ul> 
        <li><a class="app_link" href="<?php echo $GLOBALS['config']['extra']['appdown']; ?>" target="_blank" rel="noopener noreferrer">APP下载</a></li> 
        <li style="text-align:center;"><a href="javascript:void(0);" onclick="AddFavorite(document.title,location.href)">收藏</a></li> 
        <li style="text-align:right;"><a class="url_page" href="<?php echo url('user/findpass_msg'); ?>?ac=email" target="_blank" rel="noopener noreferrer">找回密码</a></li> 
       </ul> 
       <div class="clear"></div> 
      </div> 
      <div class="f_x"> 
       <i>最新网址</i> 
       <span id="target"></span> 
       <button type="button" data-clipboard-action="copy" data-clipboard-target="#target" id="copy_btn">复制分享</button> 
       <div class="clear"></div> 
      </div> 
     </div> 
     <div class="ct_nr"> 
      <div class="d_l">
       <a href="/"><img class="logo_src" src="<?php echo mac_url_img($maccms['site_logo']); ?>" /></a>
      </div> 
     </div> 
     <div class="clear"></div> 
     <div class="container"> 
      <div class="d_l" style="color:#555;text-align:center">
       ©2018 <?php echo $maccms['site_name']; ?>
       <br /> 警告︰本網站只這合十八歲或以上人士觀看。內容可能令人反感；不可將本網站的內容派發、傳閱、出售、出租、交給或借予年齡未滿18歲的人士或將本網站內容向該人士出示、播放或放映。 LEGAL DISCLAIMER WARNING: THIS FORUM CONTAINS MATERIAL WHICH MAY OFFEND AND MAY NOT BE DISTRIBUTED, CIRCULATED, SOLD, HIRED, GIVEN, LENT,SHOWN, PLAYED OR PROJECTED TO A PERSON UNDER THE AGE OF 18 YEARS. 站点申明：我们立足于美利坚合众国，受北美法律保护,未满18岁或被误导来到这里，请立即离开！
	   <br /><?php echo $maccms['site_tj']; ?> <?php echo $maccms['site_icp']; ?>
      </div> 
     </div> 
     <div class="clear"></div> 
    </div> 
   </div> 
  </div> 
	<?php $__TAG__ = '{"order":"desc","ids":"20","id":"vo","key":"key"}';$__LIST__ = model("Website")->listCacheData($__TAG__); if(is_array($__LIST__['list']) || $__LIST__['list'] instanceof \think\Collection || $__LIST__['list'] instanceof \think\Paginator): $key = 0; $__LIST__ = $__LIST__['list'];if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($key % 2 );++$key;?>
    <div class="navbar-fixed-bottom bottom_nav" id="ads_b">
      <div class="bt-bar">
        <div class="container_xf">
          <div class="row" id="bottom_a">
            <div class="telled">
              <span class="ads-close"><a style="width:25px;height:25px;display:block;" onclick="document.getElementById('ads_b').style.display='none'" href="javascript:void(0);"></a></span>
    		  <a href="<?php echo $vo['website_jumpurl']; ?>" target="_blank" rel="noopener noreferrer" class="tellpc" style="padding:11% 50%;background:url(<?php echo mac_url_img($vo['website_logo']); ?>) no-repeat;background-size:contain;background-position:top;"></a>
            </div>
          </div>
        </div>
      </div>
    </div>
    <?php endforeach; endif; else: echo "" ;endif; ?>
  <div class="m-footer" style="display:none;">
    <a class="navFooter" target="_self" href="/"><i class="fed-icon-font fed-icon-shouye"></i>首页</a>
    <button type="button" class="navFooter show-sidebar-left"><i class="fed-icon-font fed-icon-fenlei"></i>分类</button>
    <a class="navFooter" href="javascript:void(0)" onClick="popupToggle()"><i class="fed-icon-font fed-icon-fenxiang"></i>推广</a>
    <a class="navFooter" target="_self" <?php if($GLOBALS['user']['user_id']): ?> href="<?php echo mac_url('user/index'); ?>" <?php else: ?> href="<?php echo mac_url('user/login'); ?>" <?php endif; ?>><i class="fed-icon-font fed-icon-yonghu"></i>我的</a>
  </div>
  <style type="text/css">
    /*.content{width:80%;margin:200px auto;box-sizing:initial !important;}*/
    .hide_box{z-index:999;background:rgba(0,0,0,.2);left:0;top:0;height:100%;width:100%;position:fixed;display:none;box-sizing:initial !important;}
    .popup_box{width:80%;height:auto;padding:5%;background-color:#303030;border-radius:10px;position:fixed;z-index:1000;left:50%;top:50%;margin-left:-45%;margin-top:-60%;display:none;box-sizing:initial !important;}
    .popup_box img{border:none;border-width:0;box-sizing:initial !important;}
    .popup_close{float:right;display:inline-block;box-sizing:initial !important;}
    .popup_tit{width: 100%;height: 75px;text-align: center;line-height: 66px;color: #a3a3a3;font-size: 16px;margin-top: 7px;margin-right:2px;box-sizing:initial !important;}
    .popup_tit p{color:#fff;text-align:center;font-size:16px;box-sizing:initial !important;}
    .popup_img{width:140px;padding:10px;border:6px solid #c1762a;margin:0 auto;border-radius:3px;height:140px;box-sizing:initial !important;}
    .popup_img img{display:block;text-align:center;width:140px;height:140px;box-sizing:initial !important;}
    .popup_explain{text-align:center;margin:10px auto;font-size:12px;color:#fff;box-sizing:initial !important;}
    .popup_select{text-align:center;box-sizing:initial !important;}
    .popup_select #share_link{border:1px solid #fff;color:#fff;background:transparent;text-align:center;border-radius:3px;width:60%;box-sizing:initial !important;}
    .popup_info{clear:both;text-align:center;margin-top:15px;box-sizing:initial !important;}
	.popup_info a{color:#fff;text-align:center;font-size:12px;text-decoration:none;padding:5px 8px;border-radius:3px;background:#ff9c1d;border-color: #ff9c1d!important;will-change: box-shadow;-webkit-box-shadow: 0 3px 1px -2px rgba(0,0,0,.2), 0 2px 2px 0 rgba(0,0,0,.14), 0 1px 5px 0 rgba(0,0,0,.12);box-shadow: 0 3px 1px -2px rgba(0,0,0,.2), 0 2px 2px 0 rgba(0,0,0,.14), 0 1px 5px 0 rgba(0,0,0,.12);cursor:pointer;box-sizing:initial !important;}cursor:pointer;box-sizing:initial !important;}
</style>
    <div class="content">
    <div class="hide_box"></div>
    <div class="popup_box">
    	<a class="popup_close" href="javascript:void(0)" onClick="popupToggle()" title="关闭"><img src="<?php echo $maccms['path']; ?>static/images/close.jpg" alt="取消" /></a>
    	<div class="popup_tit">
    		<p>快邀请您的朋友一起畅享体验！</p>
    	</div>
    	<img src="<?php echo mac_url_img($maccms['site_waplogo']); ?>" style="display:none;" id="mylogo" />
    	<div class="popup_img" id="qrcode_zc"></div>
    	<div class="popup_explain">长按可识别、保存或分享二维码</div>
    	<div class="popup_select">
    	    <?php if(($GLOBALS['user']['group_id'] == 1) or ($GLOBALS['config']['user']['invite_reg_points'] <= 0)): ?>
    		<input type="text" id="share_link" value="<?php echo $maccms['http_type']; ?><?php echo $maccms['site_url']; ?>" class="words_input" onmouseover="this.select();" readonly="">
    		<?php else: ?>
    		<input type="text" id="share_link" value="<?php echo $maccms['http_type']; ?><?php echo $maccms['site_url']; ?><?php echo mac_url('user/reg'); ?>?uid=<?php echo $user['user_id']; ?>" class="words_input" onmouseover="this.select();" readonly="">
    		<?php endif; ?>
    	</div>
    	<div class="popup_info">
    		<a id="copy_share" class="upgrade_box" onclick="copyUrl()">复制链接</a>
    	</div>
    </div>
    </div>
	<script type="text/javascript">
		function copyUrl() {
			var Url = document.getElementById("share_link");
			Url.select(); /*选择对象*/ 
			document.execCommand("Copy"); /*执行浏览器复制命令*/ 
			alert("你的推广地址已复制，用 Ctrl+V 粘贴到浏览器打开链接");
		}
	</script>
	<script src="<?php echo $maccms['path']; ?>static/js/jquery-qrcode.min.js" type="text/javascript"></script>
	<?php if(($GLOBALS['user']['group_id'] == 1) or ($GLOBALS['config']['user']['invite_reg_points'] <= 0)): ?>
	<script type="text/javascript">
	$(function(){
	    var options = {
	    	render: "image",
	    	background: '#ffffff',//背景颜色
	        text: "<?php echo $maccms['http_type']; ?><?php echo $maccms['site_url']; ?>",//二维码内容
	        image: $('#mylogo')[0]//logo图片
	    };
		$('#qrcode_zc').empty().qrcode(options);
	})
	</script>
	<?php else: ?>
	<script type="text/javascript">
	$(function(){
	    var options = {
	    	render: "image",
	    	background: '#ffffff',//背景颜色
	        text: "<?php echo $maccms['http_type']; ?><?php echo $maccms['site_url']; ?><?php echo mac_url('user/reg'); ?>?uid=<?php echo $user['user_id']; ?>",//二维码内容
	        image: $('#mylogo')[0]//logo图片
	    };
		$('#qrcode_zc').empty().qrcode(options);
	})
	</script>
	<?php endif; ?>
    <script type="text/javascript">
    function popupToggle(){
    	$(".hide_box").fadeToggle();
    	$(".popup_box").fadeToggle();
    }
    </script>
  <?php echo $maccms['site_qj_ad']; ?>
  <script type="text/javascript" src="<?php echo $maccms['path']; ?>static/js/main.js"></script> 
  <div class="kj_dh"> 
   <ul> 
    <li><a href="#gotovideo" class="s_a">视频</a></li> 
    <li><a href="#gotoimage" class="s_b">图片</a></li> 
    <li><a href="#gotofiction" class="s_d">小说</a></li> 
    <li><a href="javascript:;" class="f_h">返回顶部</a></li> 
   </ul> 
  </div>  
 </body>
</html>